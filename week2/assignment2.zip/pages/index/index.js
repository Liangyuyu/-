//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    boolean: true,
    name: 'PROFETIONAL SKILL',
    list: [
      {
        id: '1',
        title: 'SUMMARY',
        infoUrl: '/pages/summary/summary'
      },
      {
        id: '2',
        title: 'EDUCATION',
        infoUrl: '/pages/education/education'
      },
      {
        id: '3',
        title: 'EXPERIENCE',
        infoUrl: '/pages/experience/experience'
      },
      // {
      //   id: '4',
      //   title: 'PROFETIONAL SKILL',
      //   infoUrl: '/pages/professional/professional'
      // }
    ],
    
  },
  EventHandle: function () {
    var bol = this.data.boolean;
    wx.navigateTo({
      url: '/pages/professional/professional'
    })
  },
  infor: function (e) {
    wx.navigateTo({
      url: e.currentTarget.dataset.url
          })
  }
  
})
