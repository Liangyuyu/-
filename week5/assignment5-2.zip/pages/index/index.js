Page({

  /**
   * 页面的初始数据
   */
  data: {
    items: [
      {
        data: "/images/picture.gif",
        type: "image"
      },
      {
        data: "Hello world!",
        type: "text"
      },
      {
        data: "http://www.w3school.com.cn//i/movie.mp4",
        type: "video"
      },
      {
        data: "/audio/music.mp3", //使用绝对路径
        type: "audio"
      }
    ]
  },
  musicPlayer: null,
  musicPlayerPause: false,
  audioPlay: function (e) {
    console.log(e)
    console.log(this.musicPlayer.src)
    if (this.musicPlayer.src != e.target.dataset.scr) {
      this.musicPlayer.src = e.target.dataset.scr
      this.musicPlayer.play()
      wx.showToast({
        title: '音乐播放',
        icon: 'none',
        duration: 1000
      })
    } else {
      if (this.musicPlayerPause) {
        this.musicPlayerPause = false;
        this.musicPlayer.play()
        wx.showToast({
          title: '音乐继续',
          icon: 'none',
          duration: 1000
        })
      } else {
        this.musicPlayer.pause()
      }
    }


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //注册音频
    this.musicPlayer = wx.createInnerAudioContext();
    this.musicPlayer.onPause(() => {
      this.musicPlayerPause = true;
      wx.showToast({
        title: '音乐暂停',
        icon: 'none',
        duration: 1000
      })
    });
    this.musicPlayer.onStop(() => {
      this.musicPlayerPause = false;
      wx.showToasnonet({
        title: '音乐结束',
        icon: 'none',
        duration: 1000
      })
    });
  },

  haveATry: function () {
    var items = [];
    for (var i = 0; i < 6; i++) {
      switch (Math.floor((Math.random() * 4) + 1)) {
        case 1:
          items.push({
            data: "/images/picture.gif",
            type: "image"
          });
          break;
        case 2:
          items.push({
            data: "http://www.w3school.com.cn//i/movie.mp4",
            type: "video"
          });
          break;
        case 3:
          items.push({
            data: "audio/music.mp3", //使用绝对路径
            type: "audio"
          });
          break;
        default:
          items.push({
            data: "Hello world!",
            type: "text"
          });
      }
    }
    this.setData({
      items: items
    });
  }
  
})